"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Priority_Queue_array import Priority_Queue

pq = Priority_Queue()
key = 14

l = [5,7,8,9,12,14,8]

for i in l:
    pq.insert(i)
    
print(pq._values)
target1, target2 = pq.split_key(key)
print(target1._values)
print(target2._values)