"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Priority_Queue_array import Priority_Queue
from Queue_array import Queue

def queue_is_identical(source1, source2):
    """
    ----------------
    Determines whether two given queues are identical. Entries of 
    source1 and source2 are compared and if all contents are identical
    and in the same order, returns True, otherwise returns False.
    Use: identical = queue_is_identical(source1, source2)
    ---------------
    Parameters:
        source1 - a queue (Queue)
        source2 - a queue (Queue)
    Returns:
        identical - True if source1 and source2 are identical, False otherwise. 
            source1 and source2 are unchanged. (boolean)
    ---------------
    """
    identical = True
    
    temp1 = []
    temp2 = []
    
    for element1 in source1:
        temp1.append(element1)
    
    for element2 in source2:
        temp2.append(element2)
        
    count = 0
    if len(source1) == len(source2):
        while identical != False and count < len(source1):
            if temp1[count] != temp2[count]:
                identical = False
                count = len(source1)
            count += 1
    else:
        identical = False
    
    return identical


def pq_split_key(source, key):
    """
    -------------------------------------------------------
    Splits a priority queue into two depending on an external
    priority key. The source priority queue is empty when the method
    ends. The order of the values from source is preserved.
    Use: target1, target2 = pq_split_key(source, key)
    -------------------------------------------------------
    Parameters:
        source - a priority queue (Priority_Queue)
        key - a data object (?)
    Returns:
        target1 - a priority queue that contains all values
            with priority higher than key (Priority_Queue)
        target2 - priority queue that contains all values with
            priority lower than or equal to key (Priority_Queue)
    -------------------------------------------------------
    """
    target1 = Priority_Queue()
    target2 = Priority_Queue()
    
    while source.is_empty()== False:
        
        element = source.remove()
        
        if element < key:

            target1.insert(element)
        else:
            target2.insert(element)
                       
    return target1, target2
