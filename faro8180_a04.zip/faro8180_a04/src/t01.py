"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Queue_circular import Queue

cq = Queue()

for i in [1,2,3,4,5]:
    cq.insert(i)

print ("Full?")
print (cq.is_full())
    
print ("Removing value")
print (cq.remove())
    
print ('Peeking')
print (cq.peek())
    
print ("Empty?")    
print (cq.is_empty())

