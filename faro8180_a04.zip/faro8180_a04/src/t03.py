"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Queue_array import Queue

source = Queue()
target = Queue()

for value in [5,7,8,9,12,14,8]:
    source.insert(value)

for value in [5,7,8,9,1,14,8]:
    target.insert(value)

identical = source.is_identical(target)
print (identical)
