"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import queue_is_identical
from Queue_array import Queue

source1 = Queue()
source2 = Queue()

for i in [1,2,3]:
    source1.insert(i)
for c in [1,2]:
    source2.insert(c)
     
identical = queue_is_identical(source1, source2)
print(identical)


