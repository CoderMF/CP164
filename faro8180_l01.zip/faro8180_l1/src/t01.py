"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie import Movie

title = "Dellamorte Dellamore"
year =      1994
director = "Michele Soavi"
rating =    7.2
genres =  "romance, comedy, zombie, horror"
genres = [3,4,5,8]
m1 = Movie(title, year, director, rating, genres)

string = Movie.genres_string(m1)

print (string)