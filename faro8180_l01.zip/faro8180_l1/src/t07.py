"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie_utilities import read_movies

filename = "movies.txt"
fv = open (filename,"r",encoding = "utf-8")

movies = read_movies(fv)

for i in movies:
    print (i)
