"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie_utilities import read_movies
from utilities import list_test

filename = "movies.txt"
fh = open (filename, "r")

movies = read_movies(fh)

list_test(movies)