"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie import Movie
from List_array import List

movie = Movie(None, 2007, None, None, None)

print(movie)

l = List()
n = [[],[0, 1],1,2,3,4]
for i in n:
    l.append(i)
    
for i in l:
    print(i)

val = l.remove([0])

for i in l:
    print(i)
    
print("Val: {}".format(val))