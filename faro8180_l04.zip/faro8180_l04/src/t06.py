"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from utilities import array_to_list,list_to_array
from List_array import List

llist= List()

source = [1,2,3,4,5]
# target = []

print ("source")
print (source)

# print ("list")
# for i in llist:
#     print (i)
    
# array_to_list(llist, source)
# list_to_array(llist, target)



print ("target")
print (target)