"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-04-01"
-------------------------------------------------------
"""
from test_Sorts_array import test_sort, SORTS

for sort in SORTS:
    test_sort(sort[0], sort[1]) 