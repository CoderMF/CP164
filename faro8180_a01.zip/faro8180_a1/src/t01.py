"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import is_leap_year

year = int (input ("Year: "))

leap_year = is_leap_year(year)

if leap_year == True:
    print ("The Year {} is a leap year.".format (year)) 
else:
    print ("The Year {} is not a leap year.".format (year))
    