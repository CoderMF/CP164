"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import file_analyze

file_name = "pelee.txt"
fv = open(file_name,"r", encoding = "utf-8")

u, l, d, w, r = file_analyze(fv)

print (u, l, d, w, r)