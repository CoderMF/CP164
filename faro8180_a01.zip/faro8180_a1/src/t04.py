"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import matrixes_multiply

a = [[1,2,3],[4,5,6],[9,8,7]]
b = [[10,9,8,7,13],[11,6,5,4,14],[12,3,2,1,15]]

c = matrixes_multiply(a, b)

for i in c:
    print (i)