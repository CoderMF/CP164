'''
------------------------------------------------------------
[program description]
------------------------------------------------------------
Author: Maham Farooq
ID: 200498180    
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-13"
-----------------------------------------------------------
'''

# t01
def is_leap_year(year):
    """
    -------------------------------------------------------
    Leap year determination.
    Use: leap_year = is_leap_year(year)
    -------------------------------------------------------
    Parameters:
        year - year to determine if it is a leap year (int > 0)
    Returns:
        leap_year - True if year is a leap year, False otherwise (boolean)
    -------------------------------------------------------
    """
    leap_year = 0
    if year % 4 == 0:
        leap_year = True
        if year % 100 == 0:
            leap_year  = False
            if year % 400 == 0:
                leap_year = True
            else:
                leap_year = False
        else:
            leap_year = True
    else:
        leap_year = False
    return leap_year

#t02
def clean_list(values):
    """
    -------------------------------------------------------
    Removes all duplicate values from a list: values contains
    only one copy of each of its integers. The order of values
    must be preserved.
    Use: clean_list(values)
    -------------------------------------------------------
    Parameters:
        values - a list of integers (list of int)
    Returns:
        None
    -------------------------------------------------------
    """
    clean = []
    for i in values:
        if i not in clean:
            clean.append (i)
    print (clean)
    clean = values
    return 

#t03
def matrix_transpose(a):
    """
    -------------------------------------------------------
    Transpose the contents of matrix a.
    Use: b = matrix_transpose(a):
    -------------------------------------------------------
    Parameters:
        a - a 2D list (list of lists of ?)
    Returns:
        b - the transposed matrix (list of lists of ?)
    -------------------------------------------------------
    """
    b = []
    
    for j in range (len(a[0])):
        inner = []
        for i  in range(len(a)):    
            inner.append (i)       
        b.append (inner)
    
    if len (a) == len (b):
        for i in range (len(a)):
            for j in range (len (a[0])):
                b[i][j] = a[j][i]   
    elif len (a) < len(b) or len(a) > len(b):
        for i in range (len(a)):
            for j in range (len(a[0])):
                b[j][i] = a[i][j]
    
    return b
# t04
def matrixes_multiply(a, b):
    """
    -------------------------------------------------------
    Multiplies the contents of matrixes a and b.
    If a is mxn in size, and b is nxp in size, then c is mxp.
    a and b must be unchanged.
    Use: c = matrixes_multiply(a, b)
    -------------------------------------------------------
    Parameters:
        a - a 2D list (2D list of int/float)
        b - a 2D list (2D list of int/float)
    Returns:
        c - the matrix multiple of a and b (2D list of int/float)
    -------------------------------------------------------
    """
    c = []
    for j  in range(len(b)):
        inner = []
        for i in range (len(b[j])): 
            inner.append (0)       
        c.append (inner)
       
    for i in range (len(a)):
        for j in range (len(b[i])):
            for k in range (len(b)):
                c[i][j] += a[i][k] * b[k][j]
    return c
    
# t05
def file_analyze(fv):
    """
    -------------------------------------------------------
    Analyzes the characters in a file.
    The contents of the file must be unchanged.
    Use: u, l, d, w, r = file_analyze(fv)
    -------------------------------------------------------
    Parameters:
        fv - an already open file reference (file variable)
    Returns:
        u - the number of uppercase letters in the file (int)
        l - the number of lowercase letters in the file (int)
        d - the number of digits in the file (int)
        w - the number of whitespace characters in the file (int)
        r - the number of remaining characters in the file (int)
    -------------------------------------------------------
    """
    u = 0
    l = 0
    d = 0
    w = 0
    r = 0
    
    file = fv.readlines()
    
    for line in file:
        for element in line:
            if element.isupper () == True:
                u += 1
            elif element.islower () == True:
                l += 1
            elif element.isdigit () == True:
                d += 1
            elif element.isspace () == True:
                w += 1
            else:
                r += 1
                
    return u,l,d,w,r


# t06
def dsmvwl(s):
    """
    -------------------------------------------------------
    Disemvowels a string. out contains all the characters in s
    that are not vowels. ('y' is not considered a vowel.) Case is preserved.
    Use: out = dsmvl(s)
    -------------------------------------------------------
    Parameters:
       s - a string (str)
    Returns:
       out - s with the vowels removed (str)
    -------------------------------------------------------
    """
    vowels = ["a","A","e","E","i","I","o","O","u","U"]
    for element in s:
        for i in vowels:
            if element == i:
                s = s.replace (element,"")
    return s
    
# t07
def substitute(string, ciphertext):
    """
    -------------------------------------------------------
    Encipher a string using the letter positions in ciphertext.
    Only letters are enciphered, and the returned string is
    in upper case.
    Use: estring = substitute(string, ciphertext):
    -------------------------------------------------------
    Parameters:
        string - string to encipher (str)
        ciphertext - ciphertext alphabet (str)
    Returns:
        estring - the enciphered string (str)
    -------------------------------------------------------
    """
    ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    estring_list = []
    
    for i in range(len(string)):
        letter = string[i]
        if letter.upper() in ALPHABET:
            letter = letter.upper()
            for element in range(len(ALPHABET)):
                alphabet_char = ALPHABET[element]
                if alphabet_char == letter:
                    cipher_letter = ciphertext[element]
            estring_list.append(cipher_letter)
        else:
            estring_list.append(letter)
    estring = "".join(estring_list)
    return estring
    
    
#t08
def shift(string, n):
    """
    -------------------------------------------------------
    Encipher a string using a shift cipher.
    Only letters are enciphered, and the returned string is
    in upper case.
    Use: estring = shift(string, n):
    -------------------------------------------------------
    Parameters:
        string - string to encipher (str)
        n - the number of letters to shift (int)
    Returns:
        estring - the enciphered string (str)
    -------------------------------------------------------
    """
    ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    estring = []
    
    for element in string:
        letter_upper = element.upper()
        for upper in letter_upper:
            if upper in ALPHABET:  
                for i in range(len(ALPHABET)):
                    char = ALPHABET[i]
                    if upper == char:
                        shifter = i + n + 1
                        if shifter > len(ALPHABET):
                            extra = shifter - len(ALPHABET)
                            if extra > 0:
                                shifter = extra - 1
                            else:
                                shifter = extra
                        elif shifter == len(ALPHABET):
                            shifter = 0
                        shift_char = ALPHABET[shifter]
                        estring.append(shift_char)
                        
            else:
                estring.append(letter_upper)
    return estring
            
    
    
    