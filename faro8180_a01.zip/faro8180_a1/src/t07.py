"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import substitute

fh_plain = open("pelee.txt", "r")
fh_cipher = open("substitute.txt", "w")

# Read the file
fh_plain.seek(0)
file_contents = fh_plain.readlines()
plain = "".join(file_contents)  # Create a single string to hold the contents of the file

cipher = "DAVIBROWNZCEFGHJKLMPQSTUXY"

estring = substitute(plain, cipher)

print(estring)

for char in estring:
    fh_cipher.write(char)