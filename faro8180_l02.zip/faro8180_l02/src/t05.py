"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from utilities import stack_test
from Movie_utilities import read_movies

filename = "movies.txt"
fh = open(filename,"r")


source = read_movies(fh)

stack_test(source)