"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack
from utilities import array_to_stack


stack = Stack()
source = [11, 22, 33, 44, 55, 66]
array_to_stack(stack, source)


for c in stack:
    print (c)
    
    


