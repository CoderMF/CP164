"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack
from utilities import stack_to_array


stack = Stack()
target = []
stack_to_array(stack, target)


print ("stack")
for c in stack:
    print (c)
    
print ("")
  
print ('target')  
for ele in target:
    print (ele)