"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Sorted_List_array import Sorted_List
from Movie import Movie
from Movie_utilities import read_movies

fh = open("movies.txt","r")
movies = read_movies(fh)

l = Sorted_List ()

# for i in [11,22,33,44,55]:
#     l.insert(i)
  
# value = l.remove(33)    # works
# value = l[33]    # works
# print (value)

source1 = Sorted_List()
source2 = Sorted_List()
for i in [5, 7, 1, 9, 15]:
    source1.insert(i)
for i in [12, 8, 1,2,4,1,4,3]:
    source2.insert(i)
  
# l.intersection(source1, source2)    # works
# l.union(source1, source2)   # works
l.combine(source1, source2)    #works

print ("self")
for i in l:
    print (i)