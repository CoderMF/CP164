"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from List_array import List
from Movie import Movie
from Movie_utilities import read_movies
fh = open("movies.txt","r")
movies = read_movies(fh)
l = List ()

for i in [11,22,33,44,55]:
    l.append(i)

# l.prepend(0)   # works
# value = l[2]    # __getitem__ works
# print ("value",value)
# l.clean()       # works
# target1, target2 = l.split_alt()    # works
target1, target2 = l.split()        # works

# key = 99
# l.remove_many(key)  # works

# print ("list")
# for i in l:
#     print (i)

# target = List()
# for c in []:
#     target.append(c)
# 
# b = l.is_identical(target)    #works
# print (b)
    
print ("target1")
for i in target1:
    print (i)
print ("target2")
  
for i in target2:
    print (i)
print ("self")  
for i in l:
    print (i)

# source1 = List()
# source2 = List()
# for i in [5, 7, 1, 9, 15]:
#     source1.append(i)
# for i in [12, 8, 1,2,4,1,4,3]:
#     source2.append(i)

# l.intersection(source1, source2)    # works
# l.union(source1, source2)   # works
# l.combine(source1, source2)    #works

# value = l.remove_front()    # works
# print (value)


    
