"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack
from functions import stack_reverse

source = Stack()

for value in [1,2,3,4]:
    source.push(value)

print ("Original")
for i in source:
    print (i)

stack_reverse(source)

print ("Reversed")
for c in source:
    print (c)