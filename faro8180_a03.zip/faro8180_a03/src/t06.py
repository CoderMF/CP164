"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack
from functions import reroute

opstring = "SSXSSXXX"
source = Stack()

values_in = [1,2,3,4]


values_out = reroute(opstring, values_in)


for i in source:
    print (i)
