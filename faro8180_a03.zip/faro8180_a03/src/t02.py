"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack

source = Stack()
for value in [5,7,8,9,12,14,8]:
    source.push(value)
    
target1, target2 = source.split_alt()

print ("target1")
for i in target1:
    print (i)
print ("target2")
for c in target2:
    print (c)