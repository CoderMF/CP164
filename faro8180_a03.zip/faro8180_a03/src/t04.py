"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack

source = Stack()
for value in [5,7,8,9,12,14,8]:
    source.push(value)
    
print ("Original")
for i in source:
    print (i)

source.reverse()

print ("Reversed")
for c in source:
    print (c)
    