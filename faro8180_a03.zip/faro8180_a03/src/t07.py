"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack
from functions import is_mirror_stack

mirror = is_mirror_stack("cmc", "abc", "m")
print("Mirror: {}".format(mirror.value))

mirror = is_mirror_stack("zzxzuzxzz", "xyz", "u")
print("Mirror: {}".format(mirror.value))

mirror = is_mirror_stack("cmc", "ab", "m")
print("Mirror: {}".format(mirror.value))

mirror = is_mirror_stack("zzxzxzxzz", "xyz", "u")
print("Mirror: {}".format(mirror.value))

mirror = is_mirror_stack("zzxzuzx", "xyz", "u")
print("Mirror: {}".format(mirror.value))

mirror = is_mirror_stack("cmc", "abc", "m")
print("Mirror: {}".format(mirror.value))

