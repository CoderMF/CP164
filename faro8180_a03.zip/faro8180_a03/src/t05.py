"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack
from functions import postfix

string = "4 5 + 12 * 2 "

answer = postfix(string)

print (answer)