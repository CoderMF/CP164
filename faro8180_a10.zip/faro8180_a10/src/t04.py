"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-04-08"
-------------------------------------------------------
"""
from Sorts_Deque_linked import Deque

