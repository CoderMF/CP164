"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-04-08"
-------------------------------------------------------
"""
from Sorts_List_linked import Sorts
from List_linked import List
 
 
test=List()
# radix_sort(test)
 
for i in test:
    print(i)