"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-04-08"
-------------------------------------------------------
"""
from Sorts_array import Sorts
a = Sorts()

# for i in [1,2,3,4,5,6,7,8,9,10]:
#     a.

# gnome_sort(a)

