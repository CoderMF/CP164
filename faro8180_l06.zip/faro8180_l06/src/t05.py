"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from List_linked import List

ll = List()
values = [11,22,33,44,55,66]
for i in values:
    ll.append(i)

val = ll.remove(77)

contents = []
for i in ll:
    contents.append(i)
print("Remove {}, remaining list: {}".format(val, contents))