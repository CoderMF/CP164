"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie_utilities import get_by_genres

filename = "movies.txt"
movies = open (filename,"r")
genres = [2,5,6]

m = get_by_genres(movies, genres)

print (m)
for i in m:
    print (i)