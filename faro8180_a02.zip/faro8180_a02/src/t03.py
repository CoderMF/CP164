"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie_utilities import get_by_genre

filename = "movies.txt"
movies = open (filename,"r")
genre = 8

gmovies = get_by_genre(movies, genre)

print (gmovies)
for i in gmovies:
    print (i)
