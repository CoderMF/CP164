"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie_utilities import get_by_rating

filename = "movies.txt"
movies = open (filename,"r")

rating = 0

rmovies = get_by_rating(movies, rating)

print (rmovies)
for i in rmovies:
    print (i)