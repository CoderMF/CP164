"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Movie import Movie
from Movie_utilities import genre_counts

filename = "movies.txt"
movies = open (filename,"r")

counts = genre_counts(movies)

print (Movie.GENRES)
print (counts)