"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import vowel_count

string = "Nick Mills is a student"

count = vowel_count(string)

print("String: {}\nVowel Count: {}".format(string, count))