"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import gcd
from random import randint

m = randint(0, 20000)
n = randint(-20000, 20000)

ans = gcd(m, n)
print("m: {}\tn: {}\tans: {}".format(m, n, ans))