"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import to_power

base = 0

power = 0
ans = to_power(base, power)

print("Base: {}\tPower: {}\nAnswer: {}".format(base, power, ans))