"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import is_palindrome

string = "Maham"
palindrome = is_palindrome(string)

print("String: {}\nPalindrome? {}".format(string, palindrome))