"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from functions import bag_to_set

#bag = [4,3,2,1,0]
#bag = [0,1,2,3,4]
bag = [4,5,3,4,5,2,2,4]
print("Bag: {}".format(bag))
set = bag_to_set(bag)
print("Set: {}".format(set))