"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from random import randint
from functions import recurse

x = randint(0, 5)
y = randint(0, 5)

print("x: {}\ty {}".format(x, y))
ans = recurse(x, y)
print(ans)

x = randint(0,3)
y = randint(0,3)

print("x: {}\ty {}".format(x, y))
ans = recurse(x, y)
print(ans)
