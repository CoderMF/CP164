"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""

from utilities import queue_test

filename = "movies.txt"
fh = open (filename, "r")

queue_test(fh)

