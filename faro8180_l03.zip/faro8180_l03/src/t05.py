"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Queue_array import Queue
from Priority_Queue_array import Priority_Queue
from utilities import array_to_queue,queue_to_array,array_to_pq,pq_to_array

queue = Queue()
pq = Priority_Queue()

source = [1,2,3,4,5]
target = []

print ("source")
for j in source:
    print (j)

array_to_queue(queue, source)
# queue_to_array(queue, target)
# array_to_pq(pq, source)
# pq_to_array(pq, target)

print ("queue")
for c in queue:
    print (c)
#  
# print ("pq")
# for l in pq:
#     print (l)  

# print ('target')  
# for ele in target:
#     print (ele)
