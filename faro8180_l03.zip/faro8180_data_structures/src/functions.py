"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Maham Farooq
ID: 200498180
Email: faro8180@mylaurier.ca
__updated__ = "2021-01-18"
-------------------------------------------------------
"""
from Stack_array import Stack
from inspect import stack
#t01
def stack_split_alt(source):
    """
    -------------------------------------------------------
    Splits the source stack into separate target stacks.
    When finished source stack is empty. Values are
    pushed alternately onto the returned target stacks.
    Use: target1, target2 = stack_split_alt(source)
    -------------------------------------------------------
    Parameters:
        source - the stack to split into two parts (Stack)
    Returns:
        target1 - contains alternating values from source (Stack)
        target2 - contains other alternating values from source (Stack)
    -------------------------------------------------------
    """
    count = 0
    target2 = Stack()
    target1 = Stack()
    
    if not source.is_empty() or not target1.is_empty() or not target2.is_empty():
        for i in source:
            target1.pop()
            target2.pop()
        
    while not source.is_empty():              
            if count % 2 == 0:
                target1.push(source.pop()) 
            else:
                target2.push (source.pop())
            count += 1    
            
    return target1,target2

def split_alt(self):
    """
     -------------------------------------------------------
    Splits the source stack into separate target stacks with values
    alternating into the targets. At finish source stack is empty.
    Use: target1, target2 = source.split_alt()
    -------------------------------------------------------
    Returns:
        target1 - contains alternating values from source (Stack)
        target2 - contains other alternating values from source (Stack)
    -------------------------------------------------------
    """
    count = 0
    target2 = Stack()
    target1 = Stack()
        
    for i in range (len(self._values())):
        if count % 2 == 0:
            target1.append (self._values(i))
        else:
            target2.append (self.values(i))
     
    return target1,target2
        
# t03
def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    temp = []
    
    while not source.is_empty():
        temp.append(source.pop()) 
    for i in temp:
        source.push(i)    
        
    return   


# t04
def reverse(self):
    """
    -------------------------------------------------------
    Reverses the contents of the source stack.
    Use: source.reverse()
    -------------------------------------------------------
    Returns:
        None
    -------------------------------------------------------
    """
    
        
